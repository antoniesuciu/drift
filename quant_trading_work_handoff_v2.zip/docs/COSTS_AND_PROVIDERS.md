# Providers, data choices and cost discipline

**Recorded 2026-10-28.** Figures from Gemini are **illustrative model assumptions**, not live vendor quotes or profitability projections. Confirm current broker, account, location, instrument, venue, commission tier, exchange subscriptions and applicable taxes before committing money.

## Why each provider is (or isn't) needed

| Component | Job | Current decision | Cost policy |
|---|---|---|---|
| **Interactive Brokers** | Brokerage, streaming quotes, historical API where available, and later paper account | **Selected** broker, **preferred first historical source for feasibility** | Standard API itself no separate basic fee; exchange real-time data and account eligibility may cost |
| **NautilusTrader** | Event-driven simulation and later broker adapter | Preferred engine; confirm version | Open-source, infrastructure separate |
| **Parquet** | Durable columnar copies of historical data | Use for curated datasets | Free local files |
| **DuckDB** | Query/catalog for research and analytics, `data/catalog/quantlab.duckdb` | Use when useful; no server needed | Free |
| **Polars / pandas** | Feature construction and cleaning | Choose by scale rather than mandate both | Open-source |
| **Databento** | Optional specialist historical CME/US data, including trades and quotes | **Not required initially**; evaluate if IBKR insufficient | Usage-based, quote exact request, initial credit only if eligible |
| **FirstRate Data** | Optional fixed-price historical data | Alternative | Request actual quote |
| **Alpaca** | Alternative stock broker/API and data | Not primary broker | Review later if use case demands |
| **Kraken/Coinbase/eligible venues** | Additional crypto execution/data sources | Future | Check jurisdiction, percentage fees and order books |
| **ML stack (scikit-learn, LightGBM)** | Train models after historical pipeline | Early research capability | Free locally; compute/model maintenance costs |
| **LLM providers/models** | Future filing/news/event interpretation | Provider **unselected**; not M1 | Budget API tokens, source licensing, replay/archive cost, safety evaluation before enablement |
| **Linux VPS** | Future continuous paper/live execution reliability | Not needed for offline research | Quote later, no HFT colocation assumption |

## Expected initial spending

- **M1**: $0 software/infrastructure; synthetic data only.
- **M2**: attempt authorized free/available broker historical coverage; if insufficient, quote exact external historical source **and ask before paying**.
- **M3–M4**: local historical backtesting and CPU ML using existing Ubuntu hardware, no compulsory cloud/GPU.
- **M5**: IBKR paper and *real-time* relevant feed; published CME L1 tariffs can be low for eligible nonprofessionals, but verify funding/subscription and access requirements.
- **M7**: LLM APIs or model hosting are **not free by default**; count input/output tokens, source subscriptions, data retention, inference failure and evaluation costs.
- **M8+**: VPS may be justified for availability, credential isolation and restart safety. Cost separately from per-trade execution.

## Research execution friction (illustrative, not guaranteed)

- Gemini estimates **MES/MNQ ~$1.22/round trip in broker + CME + regulatory fees** at a specified retail fee tier. Verify actual current commission and exchange rates.
- Illustrative one MES trade: $1.22 fees + $1.25 spread + $1.25 slippage = **$3.72 round trip**, without possible unusual fill failures, overnight exposure, borrow/funding or taxes.
- US stocks: IBKR Pro Tiered per-share commissions plus exchange/regulatory fees; minimum commissions matter for small lots.
- Crypto spot: percentage fees compound round-trip and may overwhelm short-horizon conditional return; vendor/market specific, not a mathematical impossibility.
- Historical OHLCV alone cannot establish true limit-order fill quality. Quote-aware replay required if execution model materially changes conclusions.

**Margin is not maximum loss.** One MES contract controls notional exposure = $5 × index level; do not scale positions from day-margin minima.

## Vendor acceptance checklist

Before accepting historical data, record venue, instrument/contract expiry, period, interval, timezone/bar timestamps and data availability, corporate/expiry/roll coverage, price/volume completeness, dataset license, update policy, retention rights, and cost. If using Databento, use its cost-estimation endpoint with exact query parameters before downloading; do not assume introductory credits apply.

Before selecting any LLM model, document exact use case, expected marginal benefit over simple keyword/statistical baselines, data licensing, token spend ceiling, reproducibility/versioning and how adversarial tool content is rejected.

## Source checkpoints (validate at point of use)

- IBKR market-data pricing: https://www.interactivebrokers.com/en/pricing/market-data-pricing.php
- IBKR futures commissions: https://www.interactivebrokers.com/en/pricing/commissions-futures.php
- IBKR paper glossary: https://www.interactivebrokers.com/campus/glossary-terms/paper-trading-account/
- NautilusTrader IBKR adapter: https://nautilustrader.io/docs/latest/integrations/interactive_brokers/
- Databento historical cost: https://databento.com/docs/api-historical/metadata/metadata-get-cost?lang=python
