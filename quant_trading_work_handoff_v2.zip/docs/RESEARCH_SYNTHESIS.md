# Gemini Deep Research — source-grounded synthesis and critical notes

**Status:** Three reports preserved byte-for-byte under `docs/research/original/`; the summary is only a research brief, **not a verified financial recommendation**.

## Across the three reports: primary themes

| Report | Main idea offered | How this project uses it |
|---|---|---|
| 01 — Broad feasibility | Compare CME micro futures, US equities, crypto; Python/NautilusTrader/IBKR; costs, timestamps and risk | Select modular data/engine/broker architecture; no blanket trust in cost/regulatory assertions |
| 02 — 5–60m strategy comparison | Strong emphasis on 15–30m opening-range breakouts; MES/MNQ fee advantages; ML meta-labeling and rigorous evaluation | Keep conditional ORB, model filtering and futures as **research candidates**, not established alpha |
| 03 — Empirical short horizon | Challenges unconditional ORB; describes **intraday time-series momentum** evidence from Gao et al. (2018) and Li et al. (2022) | Select MES ITSM **as EXP-001**; verify original studies, adapt carefully to MES, test current out-of-sample returns |

## Research candidate strategy — EXP-001

Provisional ITSM **sign-agreement adaptation**, not paper replication:

- `r_open = P(10:00 ET) / P(previous US cash close) - 1`
- `r_preclose = P(15:30 ET) / P(15:00 ET) - 1`
- After both returns are knowable, propose `LONG` if both positive, `SHORT` if both negative, otherwise `NO_TRADE`; hold at most 15:30–16:00 ET; at most one session entry.
- Apply to **specific expiring MES contracts**, with proper continuous-index/ETF research proxy and roll mapping.
- Verify the exact return definitions, sample, predictive model and execution convention in the original papers before calling this a replication.

## Evidence and significant caveats

- **Very low commissions ≠ positive expected net return.** Typical volatility does not show conditional predictability or realizable fills.
- **ORB vs ITSM:** reported academic/preprint/practitioner results are not automatically comparable; some studies' execution assumptions differ considerably. Rank as hypotheses pending reproduction.
- **IBKR EEA spot crypto:** Gemini reports contradict each other; an IBKR March 31, 2026 announcement covers eligible EEA crypto customers. Exact account/API/product eligibility still needs verification before adding an adapter.
- **FINRA PDT:** verify actual broker transition rules rather than assuming 2026 rules are applied universally.
- **Databento:** raw OHLCV `ts_event` marks **bar interval start**; avoid treating it as a completed-bar timestamp in signals.
- **Historical data:** broker history may suffice for initial research or may not have sufficient expired futures depth. Databento/FirstRate are possible substitutes only when coverage, rights, and costs justify them.
- **LLMs:** research reports discuss AI-assisted coding but offer **no validated LLM trading edge**. The user has chosen LLM agent support as a future system capability, independently of those reports.
- **ML:** LightGBM/XGBoost/meta-labeling are candidates; no report establishes a reliable repeatable *incremental* edge for our exact future trades.
- **Paper vs actual:** IBKR paper simulates executions and doesn't exactly reproduce queue priority, slippage, live liquidity or operational failures.
- **Capital/leverage:** futures tick-value economics should never be mistaken for bounded drawdown; day margin is not the maximum loss.

## Evidence to obtain before implementation/paid research

1. Original Gao et al. and Li et al. full strategy methods, including overnight timing and instrument definitions.
2. Actual IBKR history/API availability (specific expiring MES contracts, intraday depth, time bounds); whether a historical vendor is needed.
3. Broker market data permissions, futures/crypto account eligibility and all fees, priced at the specific intended account/market.
4. Correct bias-free recent historical sessions, expiry/roll rules and executable price proxy.
5. Causal multi-source and human security review before any future LLM news agent.

**Research should lead to a falsifiable experiment, not another comprehensive report unless a concrete blocker requires it.**
