# Decision log — 2026-10-28

**States:** ADOPTED (user-selected direction), PROVISIONAL (technical feasibility/validation pending), DEFERRED (not selected yet). No decision here authorizes actual trades or purchases.

| ID | State | Decision | Rationale/qualification |
|---|---|---|---|
| D-001 | **ADOPTED** | One modular, multi-asset/multi-timeframe **quant platform** with shared portfolio and risk control | Independent strategies and combined evaluation; avoid duplicated brokers |
| D-002 | **ADOPTED** | **Three agent families: rule-based, ML, LLM** | Clear separation of deterministic rules, trained models and language-based research; hybrids are compositions |
| D-003 | **ADOPTED** | Host in **GitLab**, working repo `quant-trading-lab`; package `quantlab` | User is connecting GitLab; no GitHub CI/assumptions |
| D-004 | **ADOPTED** | Parquet plus local DuckDB `data/catalog/quantlab.duckdb`; Polars selectively | Versionable dataset manifests; no operational DB commitment |
| D-005 | **PROVISIONAL** | NautilusTrader for historical/paper engine | Requires actual version/API/adapter smoke test; reuse simulator, no custom exchange |
| D-006 | **ADOPTED** | Interactive Brokers paper and prospective brokerage, Alpaca alternative | Cross-asset broker, paper account; verify API, market data and account eligibility |
| D-007 | **ADOPTED** | **Historical data provider-agnostic; evaluate IBKR first** | Databento and FirstRate optional based on verified history coverage and total cost |
| D-008 | **ADOPTED** | First asset MES future (with contract expiry and USD accounting) | Align initial study with S&P 500; research only, futures carry leverage risk |
| D-009 | **PROVISIONAL** | EXP-001 sign-agreement ITSM: previous US close→10:00 and 15:00→15:30; enter ~15:30, exit ~16:00 ET | Testable research hypothesis; not yet proven or established as paper-faithful |
| D-010 | **ADOPTED** | **ML is an early research capability** after data+baseline, before autonomous paper deployment | Compare statistical/ML hypotheses; don't wait until late infrastructure milestone |
| D-011 | **ADOPTED** | **LLM is a future research-agent family**, not an order-placement authority | External-text provenance, prompt-injection safety, causal replay and cost evaluation needed |
| D-012 | **ADOPTED** | Central deterministic risk gate applies equally to all families before paper orders | Cross-strategy limits, netting, duplicate protection; agents produce proposals |
| D-013 | **ADOPTED** | Historical/backtest → validation → IBKR paper; real money only after separate explicit signoff | No auto-promotion; paper fills not actual exchange fills |
| D-014 | **ADOPTED** | Local Ubuntu research first; no immediate VPS, L3, HFT, Redis or distributed infra | Match actual 5–60min research requirements, minimize cost |
| D-015 | **DEFERRED** | Additional crypto exchanges, FX, futures, US stocks and crypto instruments | Eligibility, fees, licenses and integrations must be assessed separately |
| D-016 | **DEFERRED** | Durable operational order-state store (SQLite/Postgres/framework persistence) | Decide based on real paper-recovery requirements; DuckDB is analytical only |
| D-017 | **ADOPTED** | Require explicit approval for any paid data, account connection, credentials, paper-order activation or live trading | Avoid accidental spend and unsafe execution |

## Explicitly not decided

- Which trading strategy, market or ML/LLM method will produce positive expectancy, if any.
- Final broker fees, futures margin, tax residence, starting capital, portfolio limits or paid data vendor.
- The optimal number of simultaneous agents or strategy combinations.
- Any concrete LLM vendor, inference model, cloud stack, prompt framework or automated decision privilege.
- Whether to persist execution state in Redis/SQLite/Postgres; no reason to choose yet.

## Evidence hierarchy

1. Official broker/data-provider/API/regulatory documents for product, fees and technical capabilities.
2. Original scientific papers and replicable methodology.
3. Own preregistered, out-of-sample **net-of-cost** experiments.
4. Gemini reports as hypothesis-generating inputs, **not** verified facts or forecasts.

## Required ADRs during implementation

Create small focused records for framework version compatibility, data vendor selection/rights, bar timestamp convention, order fill/cost modeling, ML/LLM evaluation, account safety, and any proposal/risk schema changes. Do not change ADOPTED items silently; explain alternatives and seek user approval.
