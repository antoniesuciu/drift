# Agent taxonomy and orchestration — architectural sketch

**Status:** Accepted product direction; implementation is incremental. **Agent does not imply LLM autonomy.**

## Three supported agent families

| Family | Inputs | Decision mechanism | Candidate examples | Primary evaluation |
|---|---|---|---|---|
| **Rule-based** | Causal bars/trades/quotes, calendars, fixed params | Deterministic predicates/statistics | EXP-001 ITSM; breakout; mean reversion; pairs | Replay identity, cost-adjusted OOS returns, regimes |
| **ML** | Timestamped features, trained and versioned artifacts | Statistical prediction or proposal filtering | Logistic-regression regime filter; LightGBM meta-label; independent ML signal | Train/valid/test integrity, calibration, net OOS uplift, drift |
| **LLM** | Timestamped licensed news/filings/earnings/macro text | Structured language interpretation | Earnings surprise classification; event risk flag; macro sentiment | As-of textual replay, provenance/citations, prompt-injection checks, no-LLM baseline, costs |

Hybrid rule+ML+LLM systems are a **composition of these families** through one portfolio/policy layer, not an unrestricted autonomous brokerage agent.

## Proposal to execution boundary

```text
  Market/time-series data             Point-in-time text feeds (later)
             |                                  |
     +-------+-------+                          |
     | Rule-based    |  ML family            LLM family
     | agents        |  agents               agents
     +-------+-------+-------+------------------+
                     |
             Versioned proposals (not orders)
                     |
       Validity + timing + conflict resolution
                     |
        Portfolio accounting and allocation
                     |
        NON-BYPASSABLE deterministic risk
                     |
          NautilusTrader execution engine
                     |
      IBKR PAPER adapter (approved milestone)
                     |
           Later optional other venues
```

## Proposal interface (concept, not final code contract)

Required fields: unique `proposal_id`, `agent_id`, `family`, `strategy_id`, venue-qualified `instrument_id`, `generated_at_utc`, `data_asof_utc`, explicit `intent` (LONG/SHORT/FLAT/NO_TRADE/ADVISORY), optional quantity suggestion, horizon/expiry, `model_or_rule_version`, referenced input data/artifacts, and explanatory metadata. **Proposal ≠ order**. An LLM event assessor may emit only `ADVISORY` until a separately reviewed composition policy exists. Proposed 'confidence' is not a universally comparable probability without model-specific calibration.

Execution is a separate **approved order intent** produced only after schema/time/eligibility checks, portfolio conflict resolution, risk limits and idempotency checks. The broker adapter must not be callable directly by agent modules.

## Hybrid example (future, not current behavior)

1. Deterministic momentum agent proposes `LONG MES` at time t from completed data.
2. ML model proposes a calibrated accept/reject estimate trained on time-aligned historical outcomes, *not an override of broker policy*.
3. LLM macro agent offers an evidence-linked risk advisory about a known announcement **published before t**; a deterministic approved filter may incorporate this advisory only if separately tested.
4. A portfolio risk gate determines if any proposed trade fits aggregate margin/exposure/loss limits, or rejects it. The LLM has no order placement credentials.

## Evaluation and failure assumptions

- Rule-based: lookahead controls, historical simulation, cost/slippage stress, untouched holdout.
- ML: versioned training labels, temporal splits, no leakage of future labels/scalers, calibration, model drift and benchmark comparisons.
- LLM: point-in-time text/source availability, replayability limits, structured outputs, prompt injection and hallucination defense, failure-safe handling and inference cost budgets.
- Multi-agent: correlation, net exposure, overlapping positions, contradictory signals, order deduplication, reconciliation, kill switch and attribution.

Initial coding scope is one rule-based strategy plus the minimum interfaces to keep expansion feasible. Do not build ML/LLM runtimes, LLM tool access or live execution in milestone 1.
