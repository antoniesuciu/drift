# Roadmap — gated, incremental milestones

This is a plan of **verifiable evidence/deliverables**, not a deadline, a profitability forecast, or authorization to place orders. A negative backtest is a valid scientific result. **Each milestone requires review before the next.**

| Milestone | Goal and deliverables | Acceptance gate / exclusions |
|---|---|---|
| **M0 — Research and decisions** | Preserve 3 Gemini reports, critical synthesis, decisions and draft requirements; select EXP-001 | Contradictions and uncertain claims recorded; no claim of profitable edge. |
| **M1 — Repository foundation** | GitLab repo docs/AGENTS.md, Python package, pinned environment, NautilusTrader compatibility smoke test, minimal synthetic data and pytest/CI | Offline tests pass, causality/time fixtures demonstrate correct bar availability. **No broker/API credentials/paid data**. |
| **M2 — Historical data and feature foundation** | Provider-neutral OHLCV data interface, source manifests/validation, futures expiry/roll and calendars, partitioned Parquet + light DuckDB, research feature derivation | Actual IBKR historical data adequacy tested where permitted; quote optional Databento/FirstRate only if needed; no purchases without approval. |
| **M3 — First rule-based agent** | EXP-001 MES ITSM on NautilusTrader; versioned rule proposal, orders in historical simulation only; cost/fill/PnL reports | Deterministic replay, no lookahead, explicit spread/slippage, futures multiplier and FX correctness; no profitability assumed. |
| **M4 — Statistical + ML research** | Chronological holdout, walk-forward experiments; logistic baseline, optional LightGBM/XGBoost and meta-label variants on reliable labels; first ML **research** agent | Compare net-of-cost against rule baseline, audit trials, calibration and leakage. ML uplift not assumed; failed candidates retained. No broker integration required. |
| **M5 — IBKR paper integration** | Approved IBKR paper credentials via Gateway/TWS, eligible live data, full order lifecycle logging, position reconciliation, mandatory central risk gates and kill switch | Paper-only account allowlist, recovery/disconnect/idempotency tests, realistic capital limits. **No real-money orders**. |
| **M6 — Multiple rule + ML agents** | Add independently validated strategies/horizons/instruments in **historical combined** simulations; shared signal contract, portfolio attribution and allocation | Net exposures/correlations/conflicting signals modeled; each new agent has isolated and joint results. Paper concurrency only after M5 risk tests. |
| **M7 — LLM research agents** | Optional timestamped news/earnings/macro sources, archived as-of text, structured advisory outputs, prompt injection tests and research evaluator | Reproducibility limitations, hallucination/error logs and API costs quantified; no LLM may reach broker adapter directly. |
| **M8 — Multi-agent coordination and paper** | Combine rule/ML and optional LLM advisories in one risk-governed paper system, deconfliction, monitoring, drift and allocations | Portfolio-level gates, no hidden correlated leverage, paper-only reconciliation, emergency halt tested across simultaneous agents. |
| **M9 — Markets and broker expansion** | Add eligible MNQ, US equities, crypto/FX and further timeframes, new vetted data/broker adapters | Instrument-specific contracts, regulation, data quality, cost and currency risks tested independently. |
| **M10 — Live readiness (conditional)** | Separate capital/regulatory/tax/risk review, low-size plan and independent emergency controls | **Requires new explicit human approval; never an automatic migration.** May be rejected indefinitely. |

## Research progression by family

- **Rule-based first (M3):** deterministic ITSM to establish correct timing, transactions and evaluation.
- **ML early (M4):** train and evaluate on M2 datasets, compare to controls. Avoid premature deep learning/RL claims.
- **LLM later (M7):** point-in-time textual information and security/evaluation foundations needed; advisory-only until separately approved policies exist.
- **Multi-agent later (M6/M8):** design schema in M1, but do not build orchestration before one agent runs correctly; risk safeguards precede any paper orders.

## First concrete coding task after docs approval

Set up minimum `pyproject.toml`, `src/quantlab/`, pytest and GitLab CI, and validate NautilusTrader Python compatibility against a tiny **synthetic** 1-minute OHLCV dataset with explicit UTC/ET bar start/end/availability. Avoid broker connections, paid APIs, strategy tuning, ML/LLM frameworks or empty services. Define minimal proposal types only where needed by EXP-001.

## Research safeguards across milestones

- Keep primary-paper definitions separate from any adapted momentum rule.
- Preserve actual expired MES contract ID; continuous back-adjusted prices may be useful for features but not simulated literal executable orders without careful modeling.
- Record negative trials and data provenance.
- Fill simulation and paper trading are not perfect reproductions of live execution.
- Tick/order-book subscriptions, expensive colocation, GPUs, multiple third-party LLM subscriptions and complex state databases are **not M1 prerequisites**.
