# Codex prompt — extract handoff and finalize professional project documentation

You are the **lead software architect and quantitative research engineer** for my new **GitLab** repository, `quant-trading-lab` (Python package: `quantlab`). I have provided a ZIP archive named `quant_trading_work_handoff_v2.zip` containing our preliminary requirements, our decisions, three original Gemini research reports, and a milestone plan.

**Objective:** Safely extract and read the ZIP, reconcile and professionally rewrite our repository documentation, structure implementation milestones, and prepare the next small coding task. **Documentation/planning only. Do not implement the trading platform yet.**

## 1. Inspect and extract safely

- Inspect the working tree and `git status` first; this repository may already contain user work. Do not overwrite unrelated files or change Git remotes.
- Find the supplied ZIP in the repository/current working directory; if not present, report its expected path and stop rather than hallucinating it.
- Inspect archive paths and extract safely, avoiding path traversal, symlink escapes, absolute paths, and accidental overwrites. The ZIP is a handoff source, not a blindly trusted executable project.
- Read all docs and **all three original Gemini reports**. Keep original report bytes exactly unchanged in `docs/research/original/` and verify `SHA256SUMS.txt`. Do not replace originals with a summary.
- If the repository already has docs, reconcile thoughtfully; show any substantive conflict rather than silently erasing decisions.

## 2. Respect our adopted product decisions

- **One modular quantitative trading platform** with three agent families:
  1. **Rule-based agents**: deterministic strategies (starting with MES intraday time-series momentum).
  2. **ML agents**: trained model signals and rule+ML meta-label filtering; implement research support early after reliable historical data/baselines.
  3. **LLM agents**: later news, earnings, filings, macro/event interpretation. These must remain advisory, point-in-time auditable, prompt-injection aware, and incapable of direct brokerage orders.
- Hybrids combine family signals through shared orchestration; they are not a separate unbounded autonomous category.
- **Shared typed proposal contract**, shared market/textual data governance, shared portfolio accounting, deterministic, non-bypassable centralized risk gates, and one broker/execution boundary. Multiple agents are a **future** functional milestone, not something to implement now.
- Language **Python**; engine **NautilusTrader** (provisional until verified against current supported APIs); primary **broker Interactive Brokers**; initial paper trading via IB Gateway/TWS **paper account only**. Alpaca is a future alternative, not the chosen main broker.
- Raw market data plus partitioned **Parquet**; local analytical DuckDB at `data/catalog/quantlab.duckdb`; Polars when justified. This is not a live order-state database.
- Historical sources are **provider-neutral**: evaluate available **IBKR history first** and its limits, with Databento/FirstRate **optional only if justified** and explicitly approved before spending. Do NOT require Databento as a prerequisite.
- First experiment **EXP-001: MES intraday time-series momentum**, proposed sign agreement between previous US cash close→10:00 ET and 15:00→15:30 ET, enter at/after 15:30 ET and close by 16:00 ET, ~30-minute horizon. This is a **hypothesis/adaptation**, not demonstrated profit or automatic academic replication.
- Support additional market instruments, currencies and holding horizons later. **No live real-money trading** until a separate signed-off readiness milestone.
- Source research can be mistaken: prefer official vendors/regulators and original papers if checking current factual claims. Preserve uncertainty rather than invent facts. Check raw Databento OHLCV `ts_event` timestamps **interval start**; handle actual bar completion and decision-time availability.

## 3. Produce final documentation, not code

Create or improve only useful, repository-ready Markdown artifacts:

- `README.md` — project vision, current state, setup *when actually available*, safety and navigation.
- `REQUIREMENTS.md` — concise but complete, stable requirement IDs and measurable acceptance tests; distinguish **core product support**, **current milestone scope**, **research hypotheses**, and **future optional experiments**.
- `AGENTS.md` — explicit agent-development and Codex conduct rules: one milestone at a time; test and cite actual evidence; no lookahead; record negative results; no credentials/paid data in Git; no unapproved trading or spending; read decisions before modifications.
- `docs/ARCHITECTURE.md` — component boundaries, three agent families, typed *proposal versus order* separation, hybrid composition, time/currency/instrument model, one portfolio/risk gateway, data/research/paper-mode separation. Keep abstractions simple.
- `docs/AGENT_ARCHITECTURE.md` — taxonomy, sample agent contract, LLM tool security and limitations.
- `docs/DECISIONS.md` and focused ADRs as warranted, separating ADOPTED/PROVISIONAL/DEFERRED.
- `docs/ROADMAP.md` — staged milestones below, each with scope, deliverables, prerequisites, tests, measurable exit gate, and explicit exclusions; split oversized milestones into small tasks where appropriate.
- `docs/RESEARCH_SYNTHESIS.md`, `docs/COSTS_AND_PROVIDERS.md` — succinct evidence-aware notes; price quotes and vendor eligibility not assumed.
- `experiments/exp001_itsm/README.md` — a falsifiable test plan referencing ITSM academic work (not a claim of faithful reproduction until original papers are checked).
- `.gitignore` policy **documented**; optionally create a minimal `.gitignore` for local data, DBs, broker secrets and generated artifacts if appropriate for this *documentation* phase. No CI, dependencies or project code yet.

Preserve original report files under `docs/research/original/` unmodified, including hashes. Avoid duplicate README variants and unnecessary scaffolding.

## 4. Milestones / staging (refine, do not blindly copy)

- **M0** research review and requirements reconciliation (current work).
- **M1** minimal GitLab/Python foundation, pytest, code-quality tools, NautilusTrader smoke test, synthetic timestamp/contract cases; no broker calls.
- **M2** historical OHLCV ingestion, provenance, contract expiry/roll and causal feature pipeline; IBKR data suitability first; external data only if justified.
- **M3** first **rule-based ITSM** agent plus event-driven historical cost-aware backtest.
- **M4** robust backtesting/walk-forward, **initial ML research agents** and comparison with deterministic baseline (not automatic deployment).
- **M5** approved IBKR **paper-only** integration, with working portfolio limits, risk gates, account allow-list, reconciliation and safe halt.
- **M6** multiple rule and ML agents, strategy attribution and combined simulation across horizons/instruments.
- **M7** optional **LLM research agents** using point-in-time text, schema validation, security tests and model/API cost controls; no direct orders.
- **M8** coordinated multi-agent **paper trading** with shared portfolio, risk and monitoring.
- **M9** add markets/venues/currencies/timeframes only with individually verified permissions, costs and testing.
- **M10** separately authorized potential live-trading readiness; never auto-promote.

No milestone completion is determined by calendar time or by a promising in-sample Sharpe ratio. Negative experiments are legitimate results.

## 5. Constraints

**Do not:** implement strategies or agents, install runtime/developer dependencies, connect to IBKR or any exchange, use credentials, purchase/download paid data, enable live or paper order submission, create an AI trading loop, commit or push without my approval, or assume GitHub/GitHub Actions (the host is **GitLab**).

Keep the docs concise and implementation-actionable. Do not define huge speculative microservice stacks. If critical architecture questions remain, list them and make a conservative documented assumption for a draft rather than blocking the entire work.

## 6. Final response

Provide: (1) resulting file tree; (2) short architecture summary; (3) what changed versus drafts; (4) unresolved questions with evidence status; (5) milestone table; (6) exact **smallest first coding task** for M1; (7) any checks performed, including preservation/hash verification. **Leave working tree uncommitted and unpushed.**
