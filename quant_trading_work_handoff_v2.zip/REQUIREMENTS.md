# REQUIREMENTS — Quant Trading Lab (draft v2)

**Status:** Documentation for Codex reconciliation, 2026-10-28.  
**Goal:** Modular, ML-capable quantitative trading research platform supporting **rule-based**, **ML**, and **LLM** agent families; multiple assets, currencies, horizons and strategies; historical evaluation; and later **IBKR paper trading**. No real-money execution without a distinct approval.

## 1. Product boundary and staging

- **Now:** finalize architecture and requirements, followed by offline research tooling, data integrity and deterministic backtesting. Start with **EXP-001 MES ITSM**.
- **Near-term:** build statistically sound historical data/label pipelines; evaluate rule-based baselines and **ML models early in research**, before enabling unattended paper brokerage orders.
- **Later:** compare multiple agents, run coordinated paper strategies, and investigate **LLM analysis agents** and eligible additional markets.
- **Not authorized:** paid downloads, API subscriptions, credential handling, brokerage connectivity, order submission or live-money operations without explicit separate approval for each relevant action.
- **Definitions:** An **agent** is a versioned, configurable component that consumes allowed information and emits structured trading/research proposals. It is not intrinsically an autonomous LLM, a trading account, or a separate process. An **experiment** is a reproducible hypothesis test. A **strategy** is a decision policy; agents may implement a strategy or act as filters/advisors.

## 2. Adopted, provisional, deferred decisions

| Item | Current choice | Scope/qualification |
|---|---|---|
| Repository host/name | **GitLab** / `quant-trading-lab` | User is connecting GitLab; do not assume a GitHub remote |
| Python package | `quantlab` | Shared library for research and agents |
| Language | Python | No custom C++/Rust trading core initially |
| Engine | NautilusTrader | Preferred; verify supported current APIs and IBKR adapter before coding |
| Paper broker | Interactive Brokers | IB Gateway / TWS API; paper only when enabled; Alpaca alternative only |
| Data | Source-preserving raw + curated **Parquet** | UTC timestamp and vendor provenance; Polars as useful |
| Analytical catalog | `data/catalog/quantlab.duckdb` | Local DuckDB; **not** the live order/position transaction database |
| Historical data vendors | **IBKR evaluated first**, optional Databento/FirstRate | Access/coverage/pacing/pricing decide; no automatic purchases |
| First market | CME MES futures | Contract roll, margins, tick sizes and USD exposures handled correctly |
| First candidate | EXP-001 ITSM, 30-min close window | Adaptation: previous US cash close→10:00 ET and 15:00→15:30 ET signs; enter 15:30, exit 16:00 if aligned; check paper details |
| Intended additional instruments | MNQ, liquid equities, eligible crypto and FX | Only after venue/account/data/tax/cost validation |

## 3. Platform requirements

### REQ-ARCH-001 — One platform and shared controls [CORE DESIGN]
Support any number of separately configured agent **instances** (within practical resource limits) without duplicating brokers or market data unnecessarily. Separate research/signal generation from central portfolio, risk and execution decisions. Keep common semantics across historical and paper environments while allowing simulation/live fills to differ. No architecture that requires all agents to use an LLM.

**Accept:** Architecture and test plan describe independent signal generation, duplicate/conflict handling, attribution, portfolio-level exposure and one shared broker execution boundary.

### REQ-AGENT-001 — Three family taxonomy [CORE DESIGN]
Provide documented agent families:

- **Rule-based:** deterministic functions of causally observed data and fixed parameters, including momentum, ORB, mean reversion.
- **ML:** trained inference, feature pipelines, labels, model artifacts and calibration/drift evaluation; supports independent ML signal generators and rule-plus-ML *meta-labeling*.
- **LLM:** analysis of point-in-time news, filings, earnings, macro research and structured advisory/sentiment proposals; not entitled to submit orders, modify risk limits, or treat tool content as trusted instructions.

**Accept:** Examples show a rule-only ITSM agent, a prospective ML filter, an LLM event assessor, and a hybrid composition, all interoperating through one standardized proposal contract without implying they are deployed today.

### REQ-AGENT-002 — Typed proposal and provenance [CORE DESIGN; implement incrementally]
Specify a **versioned proposal schema** containing at least `agent_id`, `agent_family`, `strategy_id`, `instrument_id` (venue/asset/contract expiry), `generated_at_utc`, `data_asof_utc`, proposed direction/action, target horizon, rationale/feature or model version, source/provenance IDs, and validity/expiry. Optional strength/confidence must clearly identify its meaning; scores from different models cannot automatically be treated as comparable probabilities. Proposal is **not an order**.

**Accept:** Schema and examples are testable, with missing/stale/future-dated data, malformed instruments, duplicate proposal IDs and conflicting proposals rejected or explicitly resolved downstream.

### REQ-DATA-001 — Historical ingestion and provenance [EARLY IMPLEMENTATION]
Support minute-level OHLCV first, extensible to trades, bids/asks, depth and point-in-time textual observations. Source adapters must be replaceable. Preserve immutable originals and metadata: vendor/source, venue, actual futures expiry, symbol mapping, acquisition and availability timestamps, time zone, coverage, schema version, checksums and usage rights. Preserve gaps instead of silently fabricating prices.

IBKR historical API may be sufficient for an initial dataset but is constrained; **Databento is OPTIONAL**. Investigate alternatives and request exact quotations for paid history only if evidenced coverage/quality needs demand it. Never silently substitute synthetic data for real data.

**Accept:** Fixtures verify duplicate/missing/out-of-order bars, invalid values, source identity, contract rolls and correct data availability. Data vendor choice is documented as a costed decision, not hardwired into agent logic.

### REQ-DATA-002 — Causality and time alignment [EARLY IMPLEMENTATION]
Use UTC internally and `America/New_York` with an exchange calendar for US cash-session signals. Maintain explicit **bar start, bar end, and when bar value became available**. Databento's raw OHLCV `ts_event` labels interval start; never use a bar's closing price before interval completion. Handle holidays, partial days, DST, session breaks, futures contract expiry/roll and delayed textual sources. ML features/labels and LLM inputs must be restricted to what was knowable at decision time.

**Accept:** Automated tests prove no lookahead at window boundaries, DST transitions, missing bars, partial sessions, futures rolls, and future publication timestamps.

### REQ-RESEARCH-001 — Reproducible strategy experiments [EARLY IMPLEMENTATION]
Every experiment records a preregistered hypothesis, exact parameters and target/horizon, instrument selection, data versions/hashes, software/commit versions, costs, source evidence, evaluation periods and ALL attempted trials. Reports include gross/net returns, fees, spread, slippage, drawdown, trade count, and limitations. Negative results are valid and must be retained.

**Accept:** Same pinned inputs can reproduce decisions and comparable metrics; generated examples and synthetic fixtures are conspicuously labeled; no fabricated positive results.

### REQ-STRAT-001 — Rule-based baseline / EXP-001 [FIRST STRATEGY]
Specify a deterministic **MES intraday time-series momentum** experiment: compare sign of previous US cash close→10:00 ET return to sign of 15:00→15:30 ET return, long if both positive, short if both negative, otherwise no trade; proposed entry at/after 15:30 ET and exit by 16:00 ET. One entry maximum per eligible full session. Determine whether signals map correctly from the underlying academic ETF/index study to MES; label this rule an **adaptation** until papers have been checked. No training data needed for this particular agent.

**Accept:** Synthetic/real-history replay tests positive, negative, disagreement, no-data, session and cost boundaries. Signal evaluated after required price information arrives, not at the same timestamp in an impossible way.

### REQ-ML-001 — ML-capable research workflow [EARLY RESEARCH, NOT M1]
Support point-in-time features and labels, chronological train/validation/test split, walk-forward evaluation, model artifacts and versioned inference. Compare basic logistic/linear models with LightGBM/XGBoost where justified. Evaluate both direct signal models and **meta-label filters** on rule-based proposals; include data leakage prevention, class imbalance, calibration, drift and meaningful net-of-cost assessment. Deeper models/RL are hypotheses, **not commitments**.

**Accept:** First ML agent must beat an explicit rule-based or simple statistical benchmark on untouched out-of-sample periods after costs, with tracked experiment lineage; failure is recorded, not optimized away.

### REQ-LLM-001 — LLM research agents [FUTURE]
Support optional LLMs for textual news/earnings/filings/macro interpretation, not direct brokerage authority. Inputs require **publication and ingestion timestamps**, source provenance and archival replay rules; outputs are a fixed schema with uncertainty and citations. Prompt-injection, hallucination, stale-data, privacy/security, model/version/prompt drift, nondeterminism and external API cost must be addressed. Define a no-LLM baseline, offline replay/evaluation set and human approval for tool access.

**Accept:** Demonstrate that an LLM cannot bypass deterministic risk gates, cannot submit live orders or change trading limits, and that out-of-time text is excluded from historical evaluation. No autonomous LLM trading in initial milestones.

### REQ-BACKTEST-001 — Event-driven simulation [EARLY IMPLEMENTATION]
Use the verified NautilusTrader API for event-driven trading simulation. Configure realistic commissions, exchange fees, tick/multiplier math, currency conversion, spread/slippage, order timing and limits; explicitly distinguish optimistic bar-only fills from quote-aware replay. No custom matching-engine rewrite.

**Accept:** Tests reconcile positions/PnL in USD and base currency and compare zero-cost vs cost-stressed controls. No strategy assumed profitable because its expected price range exceeds fees.

### REQ-VALID-001 — Scientific evaluation and anti-overfit [EARLY IMPLEMENTATION]
Use an untouched chronological holdout, prior fixed validation protocol and walk-forward/rolling tests where appropriate. Record all tuning attempts and compare against no-trade, randomized/time-shifted and simple alternative models. Use CPCV/DSR only where statistical design warrants; don't add blindly. Evaluate robustness across market regimes and over both favorable and unfavorable cost assumptions.

**Accept:** Each experiment has a reproducible evidence-led go/modify/reject verdict. No claims of live profitability from in-sample or paper PnL.

### REQ-PAPER-001 — IBKR paper-trading integration [LATER]
Enable IBKR through TWS/IB Gateway **paper credentials/account only**, with explicit user approval and required real-time market-data permissions. Paper fills are simulation and not guaranteed to represent exchange queues. Test reconnects, partial fills, rejected orders, account identity, idempotency and reconciliation against contemporaneous data. Do not rely on a $1m nominal simulator balance for realistic capital/risk assumptions.

**Accept:** Account allow-list and fail-closed paper-only configuration prevent accidental live-order submission; no usable live pathway until separately approved.

### REQ-RISK-001 — Centralized deterministic portfolio and risk [DESIGN NOW; CONTROLS BEFORE PAPER]
All agents submit proposals to one coordinated risk/portfolio manager. Aggregate positions by underlying, currency, delta/exposure, margin, leverage, correlation, losses and risk budget. Resolve opposite proposals and overlapping MES/MNQ directional risks; prevent duplicate orders and stale signals. Support strategy-level allocation and portfolio-wide halt, reconciliation and restart safety. Place **non-bypassable checks before any paper order**. ML/LLM agents must not be able to change these controls.

**Accept:** Tests show disallowed/duplicate/stale/conflicting/over-budget proposals never become orders; kill-switch and broker-disconnect scenarios fail closed.

### REQ-MARKETS-001 — Multi-asset support [FUTURE IMPLEMENTATION]
Design for stocks, CME/Eurex futures, eligible spot crypto and FX, separate venue adapters and currency-aware accounting. All broker/API/data-provider eligibility, licenses, commissions, market hours, corporate actions/rolls, market data availability and taxation must be independently verified before enabling an instrument. Alpaca is an alternative, not the primary broker.

**Accept:** Each additional instrument type has its own tested contract/spec/currency/cost model, not an assumption that symbols alone identify instruments.

### REQ-SAFETY-001 — Security, environment and authorization [ALL PHASES]
No credentials, raw vendor data, sensitive account IDs, secrets, personal records, or paid datasets committed to GitLab. Avoid real broker calls in tests. Explicit approval required for spending, credential entry, paper-order activation, and every future live-money capability. A paper/live environment switch must not be implicit. Tax and jurisdiction review precedes any real-money deployment.

**Accept:** Secret scanning/.gitignore policies, simulated-only CI, safe failure behavior, and no live credentials/order submission code in early milestones.

## 4. Quality requirements

| ID | Requirement | Verification |
|---|---|---|
| NFR-001 | Python project with pinned dependencies and documented runtime | Reproducible local install/CI |
| NFR-002 | pytest, deterministic fixtures, lint/type checks as warranted | Tests pass in GitLab CI before each signoff |
| NFR-003 | Runs initial minute-bar research on Ubuntu with ~16 GB RAM | No compulsory GPU, cluster, VPS or order-book archive |
| NFR-004 | Data/code experiment traceability; logs have run and strategy IDs | Re-run yields equivalent decisions/metrics |
| NFR-005 | Clear module boundaries and small deliverables | No empty microservices or unnecessary frameworks |
| NFR-006 | Respect open-source licenses and vendor data redistribution limits | Document licensing before external data |
| NFR-007 | Network/data failures and order uncertainty fail closed | Negative-path tests before paper activation |
| NFR-008 | Model provenance/versioning and drift evaluation | Demonstrated in ML/LLM milestones |

## 5. Milestone-gate summary

- **M0:** Research supplied; finalize contradictions and decisions. No performance claims.
- **M1:** Repo foundation, NautilusTrader smoke test and synthetic data/time correctness; no broker access.
- **M2:** Provider-agnostic historical data ingestion/validation, IBKR first if adequate; no purchase without approval.
- **M3:** Rule-based EXP-001 momentum on MES; reproducible cost-aware backtest.
- **M4:** Statistical validation + **first ML research experiments**, baseline comparisons and feature/label hygiene. No ML promise of improvement.
- **M5:** IBKR paper account integration after baseline controls, with no live capital.
- **M6:** Multiple rule-based and ML agents in combined offline simulation and portfolio attribution.
- **M7:** LLM textual/research agents with point-in-time replay and safety/evaluation harness.
- **M8:** Coordinated multi-agent paper system; central risk, allocations, conflict resolution and monitoring.
- **M9:** Additional markets, brokers and timeframes, contingent on legal/technical cost review.
- **M10:** Conditional, separately approved live-readiness evaluation; **no automatic deployment**.

## 6. Unresolved inputs

Actual trading capital/risk budget and tax jurisdiction; IBKR account permissions, subscriptions and API capability; provider datasets and pricing; exact reproduction of academic ITSM definitions; usable bid/ask/slippage data; which additional strategies and models earn out-of-sample investigation; which textual sources make LLM research both causal and economical. None may be silently assumed by Codex.
