# Alternative handoff prompt for ChatGPT Work

This package is intended primarily for **Codex**, using `CODEX_SETUP_PROMPT.md` in a local **GitLab** working tree.

If using ChatGPT Work first, ask it to read `REQUIREMENTS.md`, `README_HANDOFF.md`, `docs/AGENT_ARCHITECTURE.md`, `docs/DECISIONS.md`, `docs/ROADMAP.md`, `docs/RESEARCH_SYNTHESIS.md`, `docs/COSTS_AND_PROVIDERS.md` and all three original Gemini reports. Have it critique and produce polished documentation only. Treat reports as evidence inputs, not decisions or proof of alpha. Preserve the originals unchanged, classify open questions as unverified, and respect accepted architecture: **rule-based, ML and LLM agent families**, broker IBKR, optional Databento, an early ML research stage, future LLM/text evaluation, and a non-bypassable central risk gate. No code, network account connections, spending, credentials, trades, or commits without user approval.
