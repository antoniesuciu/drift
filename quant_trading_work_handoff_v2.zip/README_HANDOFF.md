# Quant Trading Lab — Codex documentation handoff (v2)

**Prepared:** 2026-10-28  
**State:** Pre-implementation handoff. Nothing in this archive demonstrates profitable trading, establishes an account, executes an order, or authorizes spending.  
**Intended next action:** Copy this ZIP to the newly initialized **GitLab** repository; give Codex `CODEX_SETUP_PROMPT.md` to extract, reconcile and finalize *documentation only*.

## Project identity

| Item | Agreed choice |
|---|---|
| GitLab repository | `quant-trading-lab` (recommended working name) |
| Python distribution/package | `quantlab` |
| Research analytics database | `data/catalog/quantlab.duckdb` (local, Git-ignored) |
| Market data | Immutable downloaded inputs + curated partitioned Parquet; DuckDB queries; Polars when justified |
| Primary simulation and eventual paper execution framework | NautilusTrader (verify compatibility before implementation) |
| Selected paper brokerage | Interactive Brokers via IB Gateway / TWS API |
| First empirical experiment | EXP-001 MES intraday time-series momentum (provisional adaptation, not a verified paper replication) |
| Production/live execution | **Not authorized** |

## Core product vision

Build **one modular quantitative trading platform** with three *families of independently configurable agents*:

1. **Rule-based agents:** deterministic momentum/ITSM, mean reversion, breakout, statistical arbitrage, etc.
2. **ML agents:** trained models, meta-labels, regime/return estimators, including hybrid rule+ML pipelines.
3. **LLM agents:** financial news, filings, macro/event interpretation and structured *advisory* signals. Untrusted external text must never directly authorize orders.

All agents use common research/evaluation tools and produce versioned **proposals**. One centralized signal/portfolio/risk layer decides whether a proposal may become an executable instruction. Agent family is **not** the same as asset, broker, timeframe, or deployment mode. A single agent may operate on several instruments, and one instrument may be watched by several agents; exposure must be netted/limited centrally. Hybrids are compositions, not a mandatory fourth family.

**Architectural compatibility is a current requirement.** Building functioning ML/LLM agents or a multi-agent deployment is *future milestone scope*. ML experiments should start once reliable historical/label datasets and a baseline exist, **before** production paper-trading validation; LLM agents are later and require point-in-time text/evaluation/security design.

## Supplied material

- `REQUIREMENTS.md`: draft requirements with staged acceptance criteria.
- `docs/AGENT_ARCHITECTURE.md`: agent families, shared proposal contract, safety model, hybrid examples.
- `docs/DECISIONS.md`: adopted, provisional and deferred decisions.
- `docs/ROADMAP.md`: gated, separately deliverable milestones (ML earlier; multi-agent and LLM later).
- `docs/RESEARCH_SYNTHESIS.md`: source-grounded comparison of all three Gemini reports, including contradictions.
- `docs/COSTS_AND_PROVIDERS.md`: no-purchase budget model; IBKR-first data feasibility; optional specialized vendors.
- `docs/research/original/`: **original Gemini reports copied byte-for-byte**, with `SHA256SUMS.txt`.
- `CODEX_SETUP_PROMPT.md`: **paste into Codex** in the GitLab working tree; ask it to finalize repository files, not code.
- `WORK_INSTRUCTIONS.md`: alternative short instructions for a ChatGPT Work document-revision pass; not required if using Codex.

## Non-negotiable clarification

- **IBKR** is our broker/paper-trading choice. It can supply historical data within API/coverage/pacing restrictions; **Databento is optional**, to be justified by a measured data gap and a price quote. No automatic subscription or spending.
- **ML is part of the target platform**, not dismissed. Begin reproducible ML research after usable historical data and simple baseline/training labels. Statistical baselines serve as comparisons, not a permanent restriction.
- **LLM** work is a future supported family. Its predictions and external content are neither verified facts nor order instructions; require source provenance, point-in-time availability, prompt-injection controls, and deterministic risk approval.
- The first momentum rule is **a falsifiable hypothesis**, not a claim of profitability and not automatically a faithful reproduction of Gao et al. or Li et al.
- No exchange colocation, Redis cluster, microservices, Kubernetes, or paid data is needed to **initialize** the repo.

## Illustrative future structure (create only what current work needs)

```text
quant-trading-lab/
├── README.md
├── REQUIREMENTS.md
├── AGENTS.md
├── pyproject.toml                   # later, coding milestone
├── .gitlab-ci.yml                  # later, when tests exist
├── configs/                        # typed instruments/agents/costs
├── src/quantlab/
│   ├── agents/
│   │   ├── rule_based/             # EXP-001 ITSM first
│   │   ├── ml/                     # later trained models
│   │   └── llm/                    # later textual research agents
│   ├── data/                       # acquisition, validation, as-of metadata
│   ├── backtest/                   # NautilusTrader integration
│   ├── signals/                    # normalized proposals, aggregation
│   ├── portfolio/                  # cross-agent, cross-currency accounting
│   ├── risk/                       # central deterministic approval
│   ├── execution/                  # paper-only adapter first
│   └── analytics/
├── experiments/exp001_itsm/
├── tests/
├── docs/decisions/
├── docs/research/original/
└── data/{raw,curated,catalog}/     # ignored; no raw vendor data in GitLab
```

The above is a future-oriented layout, **not permission to create dozens of empty folders or implement dormant services**. Keep the actual repository minimal until each milestone needs modules.
